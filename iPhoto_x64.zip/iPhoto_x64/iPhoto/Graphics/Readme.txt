﻿Icons used for this project comes from public source:
https://github.com/msikma/osx-folder-icons/blob/master/iconset/
https://icons8.com/
https://www.flaticon.com/
~ Krystian Grela